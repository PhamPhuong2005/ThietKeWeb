const changeColor= (num) => {
    if (num =="vang") {
        document.getElementsByTagName('body')[0].style.backgroundColor =gold;
   
    }
}